<?php


namespace App\Utils;


use RuntimeException;

class TransactionLockFailed extends RuntimeException
{

}
